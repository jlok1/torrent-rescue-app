package com.example.trapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
