import 'package:cloud_firestore/cloud_firestore.dart';

class MyUser {
  final String uid;
  final String username;
  final String fname;
  final String lname;
  final String email;
  final String contact;
  final String address;
  final String profilePictureUrl;

  const MyUser({
    required this.uid,
    required this.username,
    required this.fname,
    required this.lname,
    required this.email,
    required this.contact,
    required this.address,
    required this.profilePictureUrl,
  });

  static MyUser fromSnap(DocumentSnapshot snap) {
    var snapshot = snap.data() as Map<String, dynamic>;

    return MyUser(
      uid: snapshot["uid"],
      username: snapshot["username"],
      fname: snapshot["fname"],
      lname: snapshot["lname"],
      email: snapshot["email"],
      contact: snapshot["contact"],
      address: snapshot["address"],
      profilePictureUrl: snapshot["profilePictureUrl"],
    );
  }

  Map<String, dynamic> toJson() => {
        "uid": uid,
        "username": username,
        "fname": fname,
        "lname": lname,
        "email": email,
        "contact": contact,
        "address": address,
        "profilePictureUrl": profilePictureUrl,
      };
}
