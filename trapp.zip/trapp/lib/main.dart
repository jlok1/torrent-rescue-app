import 'package:trapp/layouts/mobile_layout.dart';
import 'package:trapp/layouts/responsive_layout.dart';
import 'package:trapp/layouts/web_layout.dart';
import 'package:trapp/providers/user_provider.dart';
import 'package:trapp/screens/edit_profile_screen.dart';
import 'package:trapp/screens/landing_screen.dart';
import 'package:trapp/screens/login_screen.dart';
import 'package:trapp/screens/register_screen.dart';
import 'package:trapp/screens/settings_screen.dart';
import 'package:trapp/theme/theme_data.dart';
import 'package:trapp/screens/profile_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (kIsWeb) {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: "AIzaSyAAfI3YKeHi30z8piCMmTbVkveX2KuFd10",
        authDomain: "trapp-1f3e0.firebaseapp.com",
        projectId: "trapp-1f3e0",
        storageBucket: "trapp-1f3e0.appspot.com",
        messagingSenderId: "15057505954",
        appId: "1:15057505954:web:7b2e0b89af973b699451fb",
        measurementId: "G-01T3BC6BY2",
      ),
    );
  } else {
    await Firebase.initializeApp();
  }
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => MyUserProvider(),
        ),
      ],
      child: MaterialApp(
        title: 'Torrent Rescue App (TRAPP)',
        theme: themeData,
        debugShowCheckedModeBanner: false,
        home: StreamBuilder(
          stream: FirebaseAuth.instance.authStateChanges(),
          builder: (ctx, userSnapshot) {
            if (userSnapshot.hasData) {
              return const ResponsiveLayout(
                mobileScreenLayout: MobileLayout(),
                webScreenLayout: WebLayout(),
              );
            } else if (userSnapshot.hasError) {
              return Center(
                child: Text('${userSnapshot.error}'),
              );
            }
            if (userSnapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
            return LandingScreen();
          },
        ),
        routes: {
          LandingScreen.routeName: (ctx) => LandingScreen(),
          LoginScreen.routeName: (ctx) => const LoginScreen(),
          RegisterScreen.routeName: (ctx) => const RegisterScreen(),
          ProfileScreen.routeName: (ctx) => const ProfileScreen(),
          EditProfileScreen.routeName: (ctx) => const EditProfileScreen(),
          SettingsScreen.routeName: (ctx) => const SettingsScreen(),
        },
      ),
    );
  }
}
