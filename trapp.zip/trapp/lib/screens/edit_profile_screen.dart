import 'dart:typed_data';
import 'package:trapp/models/user.dart';
import 'package:trapp/providers/user_provider.dart';
import 'package:trapp/services/auth_services.dart';
import 'package:trapp/utils/pick_image.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

class EditProfileScreen extends StatefulWidget {
  static const routeName = '/edit-profile';

  const EditProfileScreen({Key? key}) : super(key: key);

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _form = GlobalKey<FormState>();

  // Focus Nodes
  final _lnameFocusNode = FocusNode();
  final _emailFocusNode = FocusNode();
  final _contactFocusNode = FocusNode();
  final _addressFocusNode = FocusNode();

  var _isInit = true;
  var _isLoading = false;

  var _initValues = {
    'fname': '',
    'lname': '',
    'email': '',
    'contact': '',
    'address': '',
    'profilePictureUrl': '',
  };

  var _editedUser = const MyUser(
    uid: '',
    username: '',
    fname: '',
    lname: '',
    email: '',
    contact: '',
    address: '',
    profilePictureUrl: '',
  );

  @override
  void initState() {
    super.initState();
  }

  @override
  void didChangeDependencies() {
    if (_isInit) {
      // Fetch and set user's data
      _editedUser = Provider.of<MyUserProvider>(context, listen: false).getUser;
      _initValues = {
        'fname': _editedUser.fname,
        'lname': _editedUser.lname,
        'email': _editedUser.email,
        'contact': _editedUser.contact,
        'address': _editedUser.address,
        'profilePictureUrl': _editedUser.profilePictureUrl,
      };
    }
    _isInit = false;
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    _lnameFocusNode.dispose();
    _emailFocusNode.dispose();
    _contactFocusNode.dispose();
    _addressFocusNode.dispose();
    super.dispose();
  }

  // Set up Profile Pic
  Uint8List? _image;
  selectImage() async {
    Uint8List im = await pickImage(ImageSource.gallery);
    setState(() {
      _image = im;
    });
  }

  // Save Update Form
  Future<void> _saveForm() async {
    final isValid = _form.currentState?.validate();
    if (!isValid!) {
      return;
    }
    _form.currentState?.save();
    setState(() {
      _isLoading = true;
    });
    try {
      // Update profile at Firebase
      if (_image != null) {
        await AuthServices().updateUser(editedUser: _editedUser, file: _image!);
      } else {
        AuthServices().updateUserWithoutNewProfilePic(editedUser: _editedUser);
      }

      // Refresh user provider
      if (!mounted) return;
      Provider.of<MyUserProvider>(context, listen: false).refreshUser();
    } catch (error) {
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('An error occured!'),
          content: const Text('Something went wrong.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(ctx).pop();
              },
              child: const Text('Okay'),
            ),
          ],
        ),
      );
    }
    setState(() {
      _isLoading = false;
    });
    if (!mounted) return;
    Navigator.of(context).pop();
  }

  InputDecoration getInputDecoration(String labelName, IconData iconData) {
    return InputDecoration(
      icon: Icon(iconData),
      labelText: labelName,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profile'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveForm,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                key: _form,
                child: ListView(
                  children: [
                    // Profile Picture
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Stack(
                          children: [
                            _image != null
                                ? CircleAvatar(
                                    radius: 64,
                                    backgroundImage: MemoryImage(_image!),
                                    backgroundColor: Colors.grey,
                                  )
                                : CircleAvatar(
                                    radius: 64,
                                    backgroundImage: NetworkImage(
                                      _initValues['profilePictureUrl']
                                          as String,
                                    ),
                                    backgroundColor: Colors.grey,
                                  ),
                            Positioned(
                              bottom: -10,
                              left: 80,
                              child: IconButton(
                                onPressed: selectImage,
                                icon: const Icon(Icons.add_a_photo),
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // First Name
                    TextFormField(
                      initialValue: _initValues['fname'],
                      decoration:
                          getInputDecoration('First Name', Icons.person),
                      textInputAction: TextInputAction.next,
                      onFieldSubmitted: (_) {
                        FocusScope.of(context).requestFocus(_lnameFocusNode);
                      },
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please provide a first name.';
                        }
                        return null;
                      },
                      onSaved: (value) {
                        _editedUser = MyUser(
                          uid: _editedUser.uid,
                          username: _editedUser.username,
                          fname: value as String,
                          lname: _editedUser.lname,
                          email: _editedUser.email,
                          contact: _editedUser.contact,
                          address: _editedUser.address,
                          profilePictureUrl: _editedUser.profilePictureUrl,
                        );
                      },
                    ),
                    const SizedBox(height: 20),

                    // Last Name
                    TextFormField(
                      initialValue: _initValues['lname'],
                      decoration: getInputDecoration('Last Name', Icons.person),
                      textInputAction: TextInputAction.next,
                      onFieldSubmitted: (_) {
                        FocusScope.of(context).requestFocus(_emailFocusNode);
                      },
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please provide a last name.';
                        }
                        return null;
                      },
                      onSaved: (value) {
                        _editedUser = MyUser(
                          uid: _editedUser.uid,
                          username: _editedUser.username,
                          fname: _editedUser.fname,
                          lname: value as String,
                          email: _editedUser.email,
                          contact: _editedUser.contact,
                          address: _editedUser.address,
                          profilePictureUrl: _editedUser.profilePictureUrl,
                        );
                      },
                    ),
                    const SizedBox(height: 20),

                    // Email Address
                    TextFormField(
                      initialValue: _initValues['email'],
                      decoration:
                          getInputDecoration('Email Address', Icons.email),
                      textInputAction: TextInputAction.next,
                      keyboardType: TextInputType.emailAddress,
                      onFieldSubmitted: (_) {
                        FocusScope.of(context).requestFocus(_contactFocusNode);
                      },
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please provide an email address.';
                        }
                        return null;
                      },
                      onSaved: (value) {
                        _editedUser = MyUser(
                          uid: _editedUser.uid,
                          username: _editedUser.username,
                          fname: _editedUser.fname,
                          lname: _editedUser.lname,
                          email: value as String,
                          contact: _editedUser.contact,
                          address: _editedUser.address,
                          profilePictureUrl: _editedUser.profilePictureUrl,
                        );
                      },
                    ),
                    const SizedBox(height: 20),

                    // Contact Number
                    TextFormField(
                      initialValue: _initValues['contact'],
                      decoration:
                          getInputDecoration('Contact Number', Icons.phone),
                      textInputAction: TextInputAction.next,
                      keyboardType: TextInputType.phone,
                      onFieldSubmitted: (_) {
                        FocusScope.of(context).requestFocus(_addressFocusNode);
                      },
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please provide a contact number.';
                        }
                        return null;
                      },
                      onSaved: (value) {
                        _editedUser = MyUser(
                          uid: _editedUser.uid,
                          username: _editedUser.username,
                          fname: _editedUser.fname,
                          lname: _editedUser.lname,
                          email: _editedUser.email,
                          contact: value as String,
                          address: _editedUser.address,
                          profilePictureUrl: _editedUser.profilePictureUrl,
                        );
                      },
                    ),
                    const SizedBox(height: 20),

                    // Home Address
                    TextFormField(
                      initialValue: _initValues['address'],
                      decoration:
                          getInputDecoration('Home Address', Icons.home),
                      textInputAction: TextInputAction.newline,
                      minLines: 5,
                      maxLines: 5,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please provide a full address.';
                        }
                        return null;
                      },
                      onSaved: (value) {
                        _editedUser = MyUser(
                          uid: _editedUser.uid,
                          username: _editedUser.username,
                          fname: _editedUser.fname,
                          lname: _editedUser.lname,
                          email: _editedUser.email,
                          contact: _editedUser.address,
                          address: value as String,
                          profilePictureUrl: _editedUser.profilePictureUrl,
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
