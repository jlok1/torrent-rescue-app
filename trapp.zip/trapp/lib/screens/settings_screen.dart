import 'package:trapp/screens/landing_screen.dart';
import 'package:trapp/screens/profile_screen.dart';
import 'package:trapp/services/auth_services.dart';
import 'package:flutter/material.dart';
import 'package:confirm_dialog/confirm_dialog.dart';
import 'package:settings_ui/settings_ui.dart';

class SettingsScreen extends StatefulWidget {
  static const routeName = '/settings';

  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class SignOutProcess {
  const SignOutProcess();
  Future<void> signOut(BuildContext context, VoidCallback onSuccess) async {
    if (await confirm(
      context,
      title: const Text('Logging Out'),
      content: const Text('Are you sure you want to log out?'),
      textOK: const Text('Yes'),
      textCancel: const Text('No'),
    )) {
      await AuthServices().signOut();
      onSuccess.call();
    }
    return;
  }
}

class _SettingsScreenState extends State<SettingsScreen>
    with AutomaticKeepAliveClientMixin<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    Color primaryColor = Theme.of(context).primaryColor;

    super.build(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: SettingsList(
        lightTheme: SettingsThemeData(
          settingsListBackground: Colors.white,
          settingsSectionBackground: Colors.white,
          titleTextColor: Colors.blueGrey,
          settingsTileTextColor: Colors.blueGrey,
          tileDescriptionTextColor: Colors.blueGrey,
          leadingIconsColor: primaryColor,
        ),
        sections: [
          SettingsSection(
            title: const Text('Account'),
            tiles: <SettingsTile>[
              SettingsTile.navigation(
                leading: const Icon(Icons.info),
                title: const Text('Account Info'),
                onPressed: (context) {
                  Navigator.of(context).pushNamed(ProfileScreen.routeName);
                },
              ),
              SettingsTile.switchTile(
                onToggle: (value) {},
                initialValue: true,
                leading: const Icon(Icons.notification_add),
                title: const Text('Turn On Notifications'),
              ),
              SettingsTile.navigation(
                leading: const Icon(Icons.password),
                title: const Text('Change Password'),
              ),
              SettingsTile.navigation(
                leading: const Icon(
                  Icons.exit_to_app,
                  color: Colors.red,
                ),
                title: const Text(
                  'Log Out',
                  style: TextStyle(
                    color: Colors.red,
                  ),
                ),
                onPressed: (context) {
                  const SignOutProcess().signOut(context, () {
                    if (!mounted) return;
                    Navigator.of(context).pushNamedAndRemoveUntil(
                        LandingScreen.routeName, (route) => false);
                  });
                },
              ),
            ],
          ),
          SettingsSection(
            title: const Text('General'),
            tiles: <SettingsTile>[
              SettingsTile.navigation(
                leading: const Icon(Icons.language),
                title: const Text('Language'),
                value: const Text('English'),
              ),
              SettingsTile.navigation(
                leading: const Icon(Icons.location_city),
                title: const Text('Country or Region'),
                value: const Text('Malaysia'),
              ),
            ],
          ),
          SettingsSection(
            title: const Text('Support'),
            tiles: <SettingsTile>[
              SettingsTile.navigation(
                leading: const Icon(Icons.support_agent),
                title: const Text('Customer Support'),
              ),
            ],
          ),
          SettingsSection(
            title: const Text('About'),
            tiles: <SettingsTile>[
              SettingsTile.navigation(
                leading: const Icon(Icons.handshake_outlined),
                title: const Text('User Agreement'),
              ),
              SettingsTile.navigation(
                leading: const Icon(Icons.privacy_tip),
                title: const Text('Privacy Terms'),
              ),
              SettingsTile.navigation(
                leading: const Icon(Icons.app_settings_alt),
                title: const Text('Version'),
                value: const Text('1.0'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  bool get wantKeepAlive => true;
}
