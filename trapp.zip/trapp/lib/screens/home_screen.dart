import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with AutomaticKeepAliveClientMixin<HomeScreen> {
  final _features = [
    {'label': 'SOS', 'icon': 'assets/images/sos_icon.png'},
    {'label': 'Hotspot', 'icon': 'assets/images/map_icon.png'},
    {'label': 'Weather', 'icon': 'assets/images/rain_icon.png'},
    {'label': 'Finding Family', 'icon': 'assets/images/family_icon.png'},
    {'label': 'Medical', 'icon': 'assets/images/medical_icon.png'},
    {'label': 'Checklist', 'icon': 'assets/images/checklist_icon.png'},
  ];

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      appBar: AppBar(
        title: Image.asset(
          'assets/images/appbar_icon.png',
          width: MediaQuery.of(context).size.width / 2,
          fit: BoxFit.cover,
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 15.0, right: 15.0),
              child: Material(
                elevation: 1.0,
                borderRadius: BorderRadius.circular(5.0),
                child: TextFormField(
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    prefixIcon: Icon(Icons.search,
                        color: Theme.of(context).primaryColor, size: 30.0),
                    contentPadding:
                        const EdgeInsets.only(left: 15.0, top: 15.0),
                    hintText: 'Search',
                    hintStyle: const TextStyle(color: Colors.grey),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            _features.isNotEmpty
                ? GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _features.length,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      childAspectRatio: 1,
                      crossAxisCount: 2,
                    ),
                    itemBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Card(
                          shape: CircleBorder(
                            side: BorderSide(
                              color: Theme.of(context).primaryColor,
                              width: 3.0,
                            ),
                          ),
                          child: InkWell(
                            onTap: () {},
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Image.asset(
                                  _features[index]['icon'] ??
                                      'assets/images/not_found_icon.png',
                                  width: 56,
                                  height: 56,
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  _features[index]['label'] ?? 'N/A',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Theme.of(context).primaryColor,
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  )
                : const Center(
                    child: Text(
                      'No Features Yet.',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
            Column(
              children: [
                Text('Latest Flood News'),
                Text(
                    'I have developed an app with GridView on Flutter. GridView items are Card and the default card shape is Rectangle with a radius of 4. I know there is shape property for Card Widget and it takes ShapeBorder class but I am unable to find how to use ShapeBorder class and customize my cards in GridView. How do I go about this?'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  bool get wantKeepAlive => true;
}
