import 'package:flutter/material.dart';

Map<String, Color> colors = {
  'background': const Color.fromRGBO(255, 255, 255, 1),
  'primary': const Color.fromARGB(255, 89, 193, 218),
  'secondary': const Color.fromARGB(255, 58, 232, 221),
  'text': const Color.fromARGB(255, 35, 34, 34),
};

Size buttonSize = const Size(120, 50);

ThemeData themeData = ThemeData(
  scaffoldBackgroundColor: colors['background'],
  backgroundColor: colors['background'],
  primaryColor: colors['primary'],
  colorScheme: ColorScheme.fromSwatch().copyWith(
    secondary: colors['secondary'],
  ),
  textTheme: TextTheme(
    titleSmall: TextStyle(
      color: colors['primary'],
    ),
  ),
  iconTheme: IconThemeData(
    color: colors['primary'],
  ),
  appBarTheme: AppBarTheme(
    backgroundColor: Colors.white,
    foregroundColor: colors['primary'],
    centerTitle: true,
    elevation: 0.0,
  ),
  textButtonTheme: TextButtonThemeData(
    style: TextButton.styleFrom(
      primary: colors['text'],
      backgroundColor: colors['primary'],
      fixedSize: buttonSize,
      elevation: 0.0,
    ),
  ),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      primary: colors['primary'],
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      fixedSize: buttonSize,
      elevation: 0.0,
    ),
  ),
  outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      backgroundColor: colors['background'],
      primary: colors['text'],
      side: BorderSide(
        color: colors['primary'] as Color,
        width: 3.0,
        style: BorderStyle.solid,
      ),
      fixedSize: buttonSize,
      elevation: 0.0,
    ),
  ),
  floatingActionButtonTheme: FloatingActionButtonThemeData(
    backgroundColor: colors['primary'],
    elevation: 0.0,
  ),
);
