import 'package:trapp/models/user.dart';
import 'package:trapp/services/auth_services.dart';
import 'package:flutter/widgets.dart';

class MyUserProvider with ChangeNotifier {
  MyUser? _user;
  final AuthServices _authServices = AuthServices();

  MyUser get getUser => _user!;

  Future<void> refreshUser() async {
    MyUser user = await _authServices.getUserDetails();
    _user = user;
    notifyListeners();
  }
}
