import 'package:trapp/screens/home_screen.dart';
import 'package:trapp/screens/profile_screen.dart';
import 'package:trapp/screens/settings_screen.dart';
import 'package:flutter/material.dart';

List<Widget> screens = [
  const HomeScreen(),
  const ProfileScreen(),
  const SettingsScreen(),
];
